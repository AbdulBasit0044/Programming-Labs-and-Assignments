/*
ABDUL BASIT
193227
BSCS-6C*/
package encryption;
import java.util.Scanner;//IMPORTING PACKAGE FOR TAKING INPUT FROM USER 
/**
 *
 * @author Abdul Basit
 *///CLASS NAME
public class Encryption {

    /**
     * @param args the command line arguments
     */
    //MAIN FUNCTION BEGNINS
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);//MAKING OBJECT FOR TAKING INPUT
        
        System.out.println("Enter any number to Encrypt:");//PROMPT
        
        //DECLARING VARIABLES
        int num=input.nextInt();//TAKING INPUT FROM USER
        int number=0;
        int digit=num;
        
        //FOR LOOP TO PERFROM THE MATHEMATICS FOR ENCRYPTION
        for(int i=1000;i>=1;i=i/10){
        num=((num/i)+7)%10;
        number=number+(num*i);
        num=digit;
        }//END FOR LOOP
        
        //DECLARING NUMBERS FOR SWAPPING
        int digit1,digit2,digit3,digit4;
        
        //SEPERATING DIGIT 1 & 2 FROM NUMBER
        digit1=number/1000;
	digit2=number/100;
	digit2=digit2%10;
        //SEPARATING DIGIT 3 & 4 FROM NUMBER
	digit3=number/10;
	digit3=digit3%10;
	digit4=number%10;
        
        System.out.printf("\n*********************ENCRYPTION*******************");
        //PRINTING DIGITS AFTER PERFORMING CALCULATION FOR ENCRYPTION
	System.out.printf("\nAfter Changing       :%d	   %d	%d    %d\n",digit1,digit2,digit3,digit4);
	
        //SWAPPING DIGIT 1 & 3
	digit1=digit1+digit3;
	digit3=digit1-digit3;
	digit1=digit1-digit3;
        //SWAPPING DIGIT 2 & 4
	digit2=digit2+digit4;
	digit4=digit2-digit4;
	digit2=digit2-digit4;
        
        //PRINTING DIGITS AFTER SWAPPING
	System.out.printf("After Swapping       :%d	   %d	%d    %d\n",digit1,digit2,digit3,digit4);
	//CALCULATING ENCRYPTED NUMBER
	number=digit1*1000+digit2*100+digit3*10+digit4;
        
        System.out.printf("\n* * * * * * * * * ENCRYPTED CODE* * * * * * * * * *");
        //CHECKING IF FIRST DIGIT OF ENCRYPTED NUMBER IS 0 THEN PRINT IT
        if (digit1==0)
	{
	System.out.printf("\nEncrypted code   :0%d\n",number);
	}
	else
	{
	System.out.printf("\nEncrypted code   :%d \n",number);
	}
        
        
    }//END MAIN FUNCTION 
}//END CLASS