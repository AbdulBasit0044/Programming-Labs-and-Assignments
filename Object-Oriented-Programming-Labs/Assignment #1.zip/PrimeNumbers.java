/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primenumbers;

//@author Abdul Basit
//CLASS PRIMENUMBERS
public class PrimeNumbers {

    /**
     * @param args the command line arguments
     *///MAIN FUNCTION BEGINS
    public static void main(String[] args) {
        boolean array[]=new boolean[1000];//INITIALIZING BOOLEAN ARRAY
        
        for(int counter=1;counter<1000;counter++)
        array[counter]=true;//INITIALIZING BOOLEAN ARRAY TO TRUE
        
        
        for(int counter=2;counter<1000;counter++)//LOOP TRUE PRIME NUMBERS
        {
            for(int prime=2;prime*counter<1000;prime++){
            if(array[counter])
            array[counter*prime]=false;
            }//INNER FOR ENDS
        }//OUTER FOR ENDS

        System.out.printf("True=Prime   False=NotPrime");//PROMPT
        
        //PRINTING PRIME NUMBERS TRUE
        for(int counter=0;counter<1000;counter++)
            System.out.printf("\n%b  %d",array[counter], counter);
    }//MAIN FUNCTION ENDS
    
}//CLASS ENDS
