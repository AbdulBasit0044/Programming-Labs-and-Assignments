/*
ABDUL BASIT
193227
BSCS-6C*/
package decryption;
import java.util.Scanner;//IMPORTING PACKAGE FOR TAKING INPUT FROM USER 
/**
 *
 * @author Abdul Basit
 *///CLASS NAME
public class Decryption {

    /**
     * @param args the command line arguments
     */
    //MAIN FUNCTION BEGNINS
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);//MAKING OBJECT FOR TAKING INPUT
        
        System.out.println("Enter your four digit Encrypted code to Decrypt:");//PROMPT
        
        //DECLARING VARIABLES
        int number=input.nextInt();//TAKING INPUT FROM USER
        int num=0;
        int digit=num;
        
        //DECLARING DIGITS FOR SWAPPING
        int digit1,digit2,digit3,digit4;
        
        //SEPERATING DIGIT 1 & 2 FROM NUMBER
        digit1=number/1000;
	digit2=number/100;
	digit2=digit2%10;
        //SEPARATING DIGIT 3 & 4 FROM NUMBER
	digit3=number/10;
	digit3=digit3%10;
	digit4=number%10;
        
        
        //SWAPPING DIGIT 1 & 3
	digit1=digit1+digit3;
	digit3=digit1-digit3;
	digit1=digit1-digit3;
        //SWAPPING DIGIT 2 & 4
	digit2=digit2+digit4;
	digit4=digit2-digit4;
	digit2=digit2-digit4;
        
        //PRINTING DIGITS AFTER SWAPPING
	System.out.printf("After Swapping       :%d	   %d	%d    %d\n",digit1,digit2,digit3,digit4);
        
        //TO PERFROM THE MATHEMATICS FOR ENCRYPTION
        digit1=(digit1+3)%10;
	digit2=(digit2+3)%10;
	digit3=(digit3+3)%10;
	digit4=(digit4+3)%10;
        
        
        System.out.printf("\n*********************DECRYPTION*******************");
        //PRINTING DIGITS AFTER PERFORMING CALCULATION FOR ENCRYPTION
	System.out.printf("\nAfter Decryption       :%d	   %d	%d    %d\n",digit1,digit2,digit3,digit4);
	
        
	//CALCULATING ENCRYPTED NUMBER
	number=digit1*1000+digit2*100+digit3*10+digit4;
        
        System.out.printf("\n* * * * * * * * * DECRYPTED CODE* * * * * * * * * *");
        //CHECKING IF FIRST DIGIT OF ENCRYPTED NUMBER IS 0 THEN PRINT IT
        if (digit1==0)
	{
	System.out.printf("\nDecrypted code   :0%d\n",number);
	}
	else
	{
	System.out.printf("\nDecrypted code   :%d \n",number);
	}
        
        
    }//END MAIN FUNCTION 
}//END CLASS